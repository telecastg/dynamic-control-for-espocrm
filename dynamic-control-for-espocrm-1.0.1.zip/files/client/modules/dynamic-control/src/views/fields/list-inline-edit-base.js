/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2019 Yuri Kuznetsov, Taras Machyshyn, Oleksiy Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 * 
 * Dynamic Control - Open source plug in module for EspoCRM
 * Copyright (C) 2020 Omar A Gonsenheim
************************************************************************/

Espo.define('dynamic-control:views/fields/list-inline-edit-base', ['views/fields/base', 'dynamic-control:enhanced-dynamic-logic'], function (Dep,EnhancedDynamicLogic) {

    return Dep.extend({
        
        dynamicLogicDefs: {},
        dynamicCss: [],
        dynamicLogic: null,

        init: function() {
            Dep.prototype.init.call(this);
        },

        setup: function () {
            Dep.prototype.setup.call(this);
            //console.log("list-inline-edit-base 'this' = ",this);
            // apply enhanced dynamic logic at the field level only if displayed in list view
            if(this.mode === "list") {
                // set up the enhanced dynamic logic functionality
                this.dynamicLogicDefs = this.getMetadata().get('clientDefs.' + this.model.collection.entityType + '.dynamicLogic');
                this.dynamicLogic = new EnhancedDynamicLogic(this.dynamicLogicDefs, this);   
                this.dynamicLogic.modelsArr = [this.model];
                this.dynamicLogic.viewMode = "list-inline";   
                /*
                this.on('change', function () {
                    console.log("dynamic-control:views/fields/list-inline-edit-base.js 'change'");
                    console.log("dynamic-control:views/fields/list-inline-edit-base.js holdListDynamicLogicProcess triggered");
                    this.model.collection.trigger('holdListDynamicLogicProcess',this);
                }, this);
                        
                this.listenTo(this.model, 'after:save', function (){
                    this.dynamicLogic.process();
                    console.log("dynamic-control:views/fields/list-inline-edit-base.js dynamicLogic executed");
                    console.log("dynamic-control:views/fields/list-inline-edit-base.js releaseListDynamicLogicProcess triggered");
                    this.model.collection.trigger('releaseListDynamicLogicProcess',this);                
                }, this);
                */
            }    
        },
        
        // function invoked by dynamic-control:enhanced-dynamic-logic.js
        setFieldCss: function (cssData) {
            //console.log("dynamic-control:views/fields/list-inline-edit-base.js mode = ",this.mode);
            //console.log("dynamic-control:views/fields/list-inline-edit-base cssData ",cssData);
            this.processCss(cssData);
        },
        
        processCss: function(cssData) {
            var $row = $('tr.list-row');
            console.log("$row.length = ",$row.length);
            cssData.forEach(function (fieldData) {
                var modelId = fieldData.modelId;
                var fieldName = fieldData.field;  
                var cssObj = {};
                var cssArray = [];
                var cssAttr = '';
                var cssVal = '';
                var cssStatements = fieldData.css.split(";");
                cssStatements.forEach(function(statement){
                    cssArray = statement.split(":");
                    cssAttr = cssArray[0];
                    cssVal = cssArray[1];
                    if(cssAttr) {
                        cssObj[cssAttr] = cssVal;
                    }    
                });                     
                var $fieldCell = $('tr.list-row[data-id="' +modelId+ '"]>td.cell[data-name="' + fieldName + '"]');                    
                if($fieldCell.length > 0) {
                    $fieldCell.css(cssObj);
                } else {     
                    console.log("dynamic-control:views/fields/list-inline-edit-base ERROR $fieldCell not defined.");
                }
            }); 
        }
        
            
    });
});

